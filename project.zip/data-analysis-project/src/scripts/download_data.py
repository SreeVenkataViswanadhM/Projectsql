#!/usr/bin/env python3
# Download sample datasets for analysis

import os
import pandas as pd
from sklearn import datasets
import numpy as np

# Create data directory if it doesn't exist
os.makedirs('../../data', exist_ok=True)

# Download Iris dataset
print("Downloading Iris dataset...")
iris = datasets.load_iris(as_frame=True)
iris_df = iris.frame
iris_df.to_csv('../../data/iris_dataset.csv', index=False)
print("Iris dataset saved to data/iris_dataset.csv")

# Download Boston housing dataset
print("Downloading California housing dataset...")
housing = datasets.fetch_california_housing(as_frame=True)
housing_df = housing.frame
housing_df.to_csv('../../data/california_housing.csv', index=False)
print("California housing dataset saved to data/california_housing.csv")

# Download wine dataset
print("Downloading wine dataset...")
wine = datasets.load_wine(as_frame=True)
wine_df = wine.frame
wine_df.to_csv('../../data/wine_dataset.csv', index=False)
print("Wine dataset saved to data/wine_dataset.csv")

# Create a sample sales dataset
print("Creating sample sales dataset...")
np.random.seed(42)

# Date range for 2 years of daily data
date_range = pd.date_range(start='2021-01-01', end='2022-12-31', freq='D')
n_samples = len(date_range)

# Product categories
products = ['Electronics', 'Clothing', 'Groceries', 'Home Goods', 'Books']

# Create DataFrame
sales_data = pd.DataFrame({
    'Date': date_range,
    'Product': np.random.choice(products, size=n_samples),
    'Sales': np.random.randint(100, 5000, size=n_samples),
    'Units': np.random.randint(1, 50, size=n_samples),
    'Region': np.random.choice(['North', 'South', 'East', 'West'], size=n_samples)
})

# Add some seasonal patterns
sales_data['Month'] = sales_data['Date'].dt.month
sales_data.loc[sales_data['Month'].isin([11, 12]), 'Sales'] *= 1.5  # Holiday season boost
sales_data.loc[sales_data['Product'] == 'Electronics', 'Sales'] *= 1.2  # Electronics sell better

# Add weekend effect
sales_data['Weekday'] = sales_data['Date'].dt.weekday
sales_data.loc[sales_data['Weekday'] >= 5, 'Sales'] *= 1.3  # Weekend boost

# Drop helper columns
sales_data = sales_data.drop(['Month', 'Weekday'], axis=1)

# Save to CSV
sales_data.to_csv('../../data/sales_data.csv', index=False)
print("Sample sales dataset saved to data/sales_data.csv")

print("All datasets downloaded successfully!")
