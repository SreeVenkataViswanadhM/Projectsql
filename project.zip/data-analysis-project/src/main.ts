document.querySelector<HTMLDivElement>("#app")!.innerHTML = `<div></div>`;
