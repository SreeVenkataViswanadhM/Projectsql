#!/usr/bin/env python3
# Utility functions for data preprocessing

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler, OneHotEncoder
from sklearn.impute import SimpleImputer

def load_dataset(file_path):
    """Load a dataset from a CSV file.

    Args:
        file_path (str): Path to the CSV file

    Returns:
        pd.DataFrame: Loaded dataframe
    """
    try:
        return pd.read_csv(file_path)
    except Exception as e:
        print(f"Error loading dataset: {e}")
        return None

def check_missing_values(df):
    """Check for missing values in the dataframe.

    Args:
        df (pd.DataFrame): Input dataframe

    Returns:
        pd.DataFrame: DataFrame with missing value counts and percentages
    """
    missing = pd.DataFrame({
        'Missing Values': df.isnull().sum(),
        'Percentage': 100 * df.isnull().sum() / len(df)
    })
    return missing[missing['Missing Values'] > 0].sort_values('Missing Values', ascending=False)

def handle_missing_values(df, numeric_strategy='mean', categorical_strategy='most_frequent'):
    """Impute missing values in the dataframe.

    Args:
        df (pd.DataFrame): Input dataframe
        numeric_strategy (str): Strategy for numeric columns ('mean', 'median', 'constant')
        categorical_strategy (str): Strategy for categorical columns ('most_frequent', 'constant')

    Returns:
        pd.DataFrame: DataFrame with imputed values
    """
    # Make a copy to avoid modifying the original
    result = df.copy()

    # Identify numeric and categorical columns
    numeric_cols = result.select_dtypes(include=['int64', 'float64']).columns
    categorical_cols = result.select_dtypes(include=['object', 'category']).columns

    # Impute numeric columns
    if len(numeric_cols) > 0:
        num_imputer = SimpleImputer(strategy=numeric_strategy)
        result[numeric_cols] = num_imputer.fit_transform(result[numeric_cols])

    # Impute categorical columns
    if len(categorical_cols) > 0:
        cat_imputer = SimpleImputer(strategy=categorical_strategy)
        result[categorical_cols] = cat_imputer.fit_transform(result[categorical_cols])

    return result

def encode_categorical_features(df, columns, drop_first=True):
    """Encode categorical features using one-hot encoding.

    Args:
        df (pd.DataFrame): Input dataframe
        columns (list): List of categorical columns to encode
        drop_first (bool): Whether to drop the first category in each feature

    Returns:
        pd.DataFrame: DataFrame with encoded features
    """
    return pd.get_dummies(df, columns=columns, drop_first=drop_first)

def scale_features(df, columns, method='standard'):
    """Scale numeric features.

    Args:
        df (pd.DataFrame): Input dataframe
        columns (list): List of columns to scale
        method (str): Scaling method ('standard' or 'minmax')

    Returns:
        pd.DataFrame: DataFrame with scaled features
    """
    # Make a copy to avoid modifying the original
    result = df.copy()

    if method == 'standard':
        scaler = StandardScaler()
    elif method == 'minmax':
        scaler = MinMaxScaler()
    else:
        raise ValueError("Method must be either 'standard' or 'minmax'")

    result[columns] = scaler.fit_transform(result[columns])

    return result

def create_date_features(df, date_column):
    """Extract useful features from a date column.

    Args:
        df (pd.DataFrame): Input dataframe
        date_column (str): Name of the date column

    Returns:
        pd.DataFrame: DataFrame with additional date features
    """
    # Make a copy to avoid modifying the original
    result = df.copy()

    # Ensure the column is in datetime format
    result[date_column] = pd.to_datetime(result[date_column])

    # Extract date features
    result['year'] = result[date_column].dt.year
    result['month'] = result[date_column].dt.month
    result['day'] = result[date_column].dt.day
    result['dayofweek'] = result[date_column].dt.dayofweek
    result['quarter'] = result[date_column].dt.quarter
    result['is_weekend'] = result['dayofweek'].isin([5, 6]).astype(int)

    return result

def detect_outliers(df, column, method='iqr', threshold=1.5):
    """Detect outliers in a specific column.

    Args:
        df (pd.DataFrame): Input dataframe
        column (str): Column to check for outliers
        method (str): Method to use ('iqr' or 'zscore')
        threshold (float): Threshold for outlier detection

    Returns:
        pd.Series: Boolean series indicating outliers
    """
    if method == 'iqr':
        Q1 = df[column].quantile(0.25)
        Q3 = df[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - threshold * IQR
        upper_bound = Q3 + threshold * IQR
        return (df[column] < lower_bound) | (df[column] > upper_bound)

    elif method == 'zscore':
        from scipy import stats
        z_scores = np.abs(stats.zscore(df[column]))
        return z_scores > threshold

    else:
        raise ValueError("Method must be either 'iqr' or 'zscore'")

def remove_outliers(df, column, method='iqr', threshold=1.5):
    """Remove outliers from the dataframe.

    Args:
        df (pd.DataFrame): Input dataframe
        column (str): Column to check for outliers
        method (str): Method to use ('iqr' or 'zscore')
        threshold (float): Threshold for outlier detection

    Returns:
        pd.DataFrame: DataFrame with outliers removed
    """
    outliers = detect_outliers(df, column, method, threshold)
    return df[~outliers].reset_index(drop=True)
