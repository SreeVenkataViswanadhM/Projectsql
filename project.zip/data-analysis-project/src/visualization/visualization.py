#!/usr/bin/env python3
# Utility functions for data visualization

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.ticker import FuncFormatter
import os

# Set default styles for plots
plt.style.use('seaborn-v0_8-whitegrid')
sns.set_palette('viridis')

def save_figure(fig, filename, output_dir='../../outputs/figures', dpi=300):
    """Save a figure to disk.

    Args:
        fig: Matplotlib figure object
        filename (str): Name of the file (without extension)
        output_dir (str): Directory to save the figure
        dpi (int): Resolution of the figure
    """
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)

    # Save the figure
    fig.savefig(f"{output_dir}/{filename}.png", dpi=dpi, bbox_inches='tight')
    print(f"Figure saved to {output_dir}/{filename}.png")

def distribution_plot(df, column, bins=30, kde=True, figsize=(10, 6), title=None, save=False, filename=None):
    """Plot the distribution of a numeric variable.

    Args:
        df (pd.DataFrame): Input dataframe
        column (str): Column to plot
        bins (int): Number of bins for histogram
        kde (bool): Whether to plot kernel density estimate
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    fig, ax = plt.subplots(figsize=figsize)

    # Plot histogram with KDE
    sns.histplot(df[column], bins=bins, kde=kde, ax=ax)

    # Set title and labels
    if title:
        ax.set_title(title, fontsize=14)
    else:
        ax.set_title(f"Distribution of {column}", fontsize=14)

    ax.set_xlabel(column, fontsize=12)
    ax.set_ylabel('Frequency', fontsize=12)

    # Add descriptive statistics as text
    stats_text = (
        f"Mean: {df[column].mean():.2f}\n"
        f"Median: {df[column].median():.2f}\n"
        f"Std Dev: {df[column].std():.2f}\n"
        f"Min: {df[column].min():.2f}\n"
        f"Max: {df[column].max():.2f}"
    )

    # Place the text box in the upper right corner
    props = dict(boxstyle='round', facecolor='white', alpha=0.5)
    ax.text(0.95, 0.95, stats_text, transform=ax.transAxes, fontsize=10,
           verticalalignment='top', horizontalalignment='right', bbox=props)

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def correlation_heatmap(df, method='pearson', figsize=(12, 10), title=None, save=False, filename=None):
    """Plot a correlation heatmap for numeric columns.

    Args:
        df (pd.DataFrame): Input dataframe
        method (str): Correlation method ('pearson', 'spearman', or 'kendall')
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    # Calculate correlation matrix
    corr_matrix = df.select_dtypes(include=['int64', 'float64']).corr(method=method)

    # Create figure
    fig, ax = plt.subplots(figsize=figsize)

    # Create heatmap
    mask = np.triu(np.ones_like(corr_matrix, dtype=bool))  # Mask for upper triangle
    cmap = sns.diverging_palette(220, 10, as_cmap=True)  # Diverging colormap

    sns.heatmap(corr_matrix, mask=mask, cmap=cmap, vmax=1, vmin=-1, center=0,
                annot=True, fmt=".2f", square=True, linewidths=.5, ax=ax)

    # Set title
    if title:
        ax.set_title(title, fontsize=16)
    else:
        ax.set_title(f'{method.capitalize()} Correlation Heatmap', fontsize=16)

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def bar_plot(df, x, y, hue=None, figsize=(10, 6), title=None, sort=True, save=False, filename=None):
    """Create a bar plot.

    Args:
        df (pd.DataFrame): Input dataframe
        x (str): Column for x-axis
        y (str): Column for y-axis
        hue (str): Column for color grouping
        figsize (tuple): Figure size
        title (str): Plot title
        sort (bool): Whether to sort bars by y-value
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    # Create a copy of the dataframe for sorting
    plot_df = df.copy()

    # Sort the dataframe if requested
    if sort:
        if hue:
            # Can't easily sort with hue, so we'll just group and sort the groups
            grouped = plot_df.groupby(x)[y].mean().sort_values(ascending=False)
            plot_df[x] = pd.Categorical(plot_df[x], categories=grouped.index, ordered=True)
        else:
            # Sort directly
            plot_df = plot_df.sort_values(by=y, ascending=False)

    # Create figure
    fig, ax = plt.subplots(figsize=figsize)

    # Create bar plot
    sns.barplot(x=x, y=y, hue=hue, data=plot_df, ax=ax)

    # Set title and labels
    if title:
        ax.set_title(title, fontsize=14)
    else:
        ax.set_title(f"{y} by {x}", fontsize=14)

    ax.set_xlabel(x, fontsize=12)
    ax.set_ylabel(y, fontsize=12)

    # Format y-axis with commas for thousands
    ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{x:,.0f}'))

    # Rotate x-axis labels if they are likely to overlap
    if len(plot_df[x].unique()) > 5:
        plt.xticks(rotation=45, ha='right')

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def scatter_plot(df, x, y, hue=None, size=None, figsize=(10, 6), title=None, save=False, filename=None):
    """Create a scatter plot.

    Args:
        df (pd.DataFrame): Input dataframe
        x (str): Column for x-axis
        y (str): Column for y-axis
        hue (str): Column for color coding points
        size (str): Column for sizing points
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    # Create figure
    fig, ax = plt.subplots(figsize=figsize)

    # Create scatter plot
    scatter = sns.scatterplot(x=x, y=y, hue=hue, size=size, data=df, ax=ax)

    # Set title and labels
    if title:
        ax.set_title(title, fontsize=14)
    else:
        ax.set_title(f"{y} vs {x}", fontsize=14)

    ax.set_xlabel(x, fontsize=12)
    ax.set_ylabel(y, fontsize=12)

    # Add a trend line
    sns.regplot(x=x, y=y, data=df, scatter=False, ax=ax, color='red', line_kws={"linestyle": "--"})

    # Calculate correlation coefficient
    corr = df[[x, y]].corr().iloc[0, 1]

    # Add correlation text
    ax.text(0.05, 0.95, f'Correlation: {corr:.2f}', transform=ax.transAxes,
            fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.5))

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def time_series_plot(df, date_column, value_column, freq=None, figsize=(14, 7), title=None,
                   save=False, filename=None):
    """Create a time series plot.

    Args:
        df (pd.DataFrame): Input dataframe
        date_column (str): Column with dates
        value_column (str): Column with values to plot
        freq (str): Frequency for resampling (e.g., 'M' for month, 'Q' for quarter)
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    # Create a copy of the dataframe
    plot_df = df.copy()

    # Ensure date column is datetime
    plot_df[date_column] = pd.to_datetime(plot_df[date_column])

    # Set the date column as index
    plot_df = plot_df.set_index(date_column)

    # Resample if frequency is specified
    if freq:
        plot_df = plot_df[[value_column]].resample(freq).mean()

    # Create figure
    fig, ax = plt.subplots(figsize=figsize)

    # Plot the time series
    ax.plot(plot_df.index, plot_df[value_column], marker='o', linestyle='-', linewidth=1, markersize=4)

    # Set title and labels
    if title:
        ax.set_title(title, fontsize=14)
    else:
        ax.set_title(f"{value_column} Over Time", fontsize=14)

    ax.set_xlabel('Date', fontsize=12)
    ax.set_ylabel(value_column, fontsize=12)

    # Format y-axis with commas for thousands
    ax.yaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{x:,.0f}'))

    # Rotate x-axis labels
    plt.xticks(rotation=45, ha='right')

    # Add grid
    ax.grid(True, alpha=0.3)

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def boxplot(df, x, y, hue=None, figsize=(10, 6), title=None, save=False, filename=None):
    """Create a box plot.

    Args:
        df (pd.DataFrame): Input dataframe
        x (str): Column for x-axis (categorical)
        y (str): Column for y-axis (numerical)
        hue (str): Column for color grouping
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    # Create figure
    fig, ax = plt.subplots(figsize=figsize)

    # Create box plot
    sns.boxplot(x=x, y=y, hue=hue, data=df, ax=ax)

    # Set title and labels
    if title:
        ax.set_title(title, fontsize=14)
    else:
        ax.set_title(f"Distribution of {y} by {x}", fontsize=14)

    ax.set_xlabel(x, fontsize=12)
    ax.set_ylabel(y, fontsize=12)

    # Rotate x-axis labels if they are likely to overlap
    if len(df[x].unique()) > 5:
        plt.xticks(rotation=45, ha='right')

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def pie_chart(df, column, figsize=(10, 10), title=None, save=False, filename=None):
    """Create a pie chart.

    Args:
        df (pd.DataFrame): Input dataframe
        column (str): Column for pie chart categories
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        matplotlib.figure.Figure: The figure object
    """
    # Count values in the column
    counts = df[column].value_counts()

    # Create figure
    fig, ax = plt.subplots(figsize=figsize)

    # Create pie chart
    wedges, texts, autotexts = ax.pie(
        counts,
        labels=counts.index,
        autopct='%1.1f%%',
        textprops={'fontsize': 12},
        startangle=90,
        shadow=False,
        wedgeprops={'linewidth': 1, 'edgecolor': 'white'}
    )

    # Make autopct text white for better visibility
    for autotext in autotexts:
        autotext.set_color('white')

    # Set title
    if title:
        ax.set_title(title, fontsize=14)
    else:
        ax.set_title(f"Distribution of {column}", fontsize=14)

    # Equal aspect ratio ensures that pie is drawn as a circle
    ax.axis('equal')

    # Add a legend with the absolute count
    legend_labels = [f'{label} ({count})' for label, count in zip(counts.index, counts)]
    ax.legend(wedges, legend_labels, title=column, loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(fig, filename)

    return fig

def pairplot(df, columns=None, hue=None, figsize=(12, 12), title=None, save=False, filename=None):
    """Create a pair plot.

    Args:
        df (pd.DataFrame): Input dataframe
        columns (list): List of columns to include
        hue (str): Column for color grouping
        figsize (tuple): Figure size
        title (str): Plot title
        save (bool): Whether to save the plot
        filename (str): Filename to save the plot (without extension)

    Returns:
        seaborn.axisgrid.PairGrid: The pair grid object
    """
    # Create subset of dataframe if columns are specified
    if columns:
        plot_df = df[columns].copy()
        if hue and hue not in columns:
            plot_df[hue] = df[hue]
    else:
        plot_df = df.select_dtypes(include=['int64', 'float64']).copy()
        if hue:
            plot_df[hue] = df[hue]

    # Create pair plot
    pair_grid = sns.pairplot(
        plot_df,
        hue=hue,
        height=figsize[0]/len(plot_df.columns),
        corner=True,
        diag_kind='kde'
    )

    # Set title if provided
    if title:
        pair_grid.fig.suptitle(title, fontsize=16, y=1.02)

    plt.tight_layout()

    # Save the figure if requested
    if save and filename:
        save_figure(pair_grid.fig, filename)

    return pair_grid
